import Decoration9 from './src/main.vue'

export default function (Vue) {
  Vue.component(Decoration9.name, Decoration9)
}
