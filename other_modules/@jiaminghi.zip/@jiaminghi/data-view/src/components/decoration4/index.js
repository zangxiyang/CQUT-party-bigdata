import Decoration4 from './src/main.vue'

export default function (Vue) {
  Vue.component(Decoration4.name, Decoration4)
}
