import BorderBox9 from './src/main.vue'

export default function (Vue) {
  Vue.component(BorderBox9.name, BorderBox9)
}
