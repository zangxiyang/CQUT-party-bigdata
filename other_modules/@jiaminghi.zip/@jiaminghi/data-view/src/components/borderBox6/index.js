import BorderBox6 from './src/main.vue'

export default function (Vue) {
  Vue.component(BorderBox6.name, BorderBox6)
}
