import BorderBox8 from './src/main.vue'

export default function (Vue) {
  Vue.component(BorderBox8.name, BorderBox8)
}
