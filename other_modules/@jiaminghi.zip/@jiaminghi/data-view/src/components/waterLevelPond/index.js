import WaterLevelPond from './src/main.vue'

export default function (Vue) {
  Vue.component(WaterLevelPond.name, WaterLevelPond)
}
